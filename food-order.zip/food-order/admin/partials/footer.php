<html>
<div class="footer" style="background-color:#283812; ">
    <div class="wrapper">
        <p class="text-center" style="background-color:#283812; ">2020 All rights reserved, Some Resturant. devloped By - <a style="color:#a9c77f;"href="#"> Bishan And Group</a></p>
        <div>
</div>
</body>
</html>
